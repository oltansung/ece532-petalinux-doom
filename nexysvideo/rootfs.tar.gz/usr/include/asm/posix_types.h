/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_MICROBLAZE_POSIX_TYPES_H
#define _ASM_MICROBLAZE_POSIX_TYPES_H

typedef unsigned short	__kernel_mode_t;
#define __kernel_mode_t __kernel_mode_t

#include <asm-generic/posix_types.h>

#endif /* _ASM_MICROBLAZE_POSIX_TYPES_H */
